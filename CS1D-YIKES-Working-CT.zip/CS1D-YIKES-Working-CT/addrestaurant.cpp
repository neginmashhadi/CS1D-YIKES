#include "addrestaurant.h"
#include "ui_addrestaurant.h"
#include <QLabel>

addRestaurant::addRestaurant(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addRestaurant)
{
    ui->setupUi(this);
    ui->buttonBox->button(QDialogButtonBox::Close)->hide();
    clicked = false;
}

addRestaurant::~addRestaurant()
{
    delete ui;
}

bool addRestaurant::returnClicked()
{
    return clicked;
}

void addRestaurant::on_pushButton_clicked()
{
    ui->buttonBox->button(QDialogButtonBox::Close)->show();
    ui->buttonBox->button(QDialogButtonBox::Cancel)->hide();

    ui->pushButton->hide();

    QLabel *lable = new QLabel;
    lable->setText("Adding 2 New Restaurants...");

    ui->horizontalLayout->addWidget(lable);

    clicked = true;
}
