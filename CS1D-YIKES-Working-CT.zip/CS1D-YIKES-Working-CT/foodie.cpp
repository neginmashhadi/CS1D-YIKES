#include "foodie.h"

Foodie::Foodie()
{

}
