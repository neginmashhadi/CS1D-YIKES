#include "structs.h"
#include <QDebug>


void AddingRestaurants(bool checked, Database * DB)
{
    if(checked)
    {
        vector<Restaurant> *list;

        list = DB->InputNewFileToDatabase(":/files/NewInput.txt");

        for(unsigned int i = 0; i < list->at(0).GetDistancesToRestaurants().size() - 2; i++)
        {
            if(i < 10)
            {
                DB->EditTotalDistances(DB->GetRestuarantList().at(i).GetID(), 12);
            }
            if(DB->RestaurantExists(list->at(0).GetDistancesToRestaurants().at(i).GetNextID()))
            {
                if(DB->AddDistance(list->at(0).GetDistancesToRestaurants().at(i).GetNextID(),
                                list->at(0).GetDistancesToRestaurants().at(i).GetCurrentRestaurantID(),
                                list->at(0).GetDistancesToRestaurants().at(i).GetMiles()))
                {

                    qDebug() << list->at(0).GetDistancesToRestaurants().at(i).GetCurrentRestaurantID();
                    qDebug() <<list->at(0).GetDistancesToRestaurants().at(i).GetNextID();
                    qDebug() <<list->at(0).GetDistancesToRestaurants().at(i).GetMiles();
                    qDebug() << "Add distance Successful";
                }
                else
                {
                    qDebug() << "FUCKKKKK IT FAILED";
                }
            }
        }

        for(unsigned int i = 0; i < list->at(1).GetDistancesToRestaurants().size() - 2; i++)
        {
            if(DB->RestaurantExists(list->at(1).GetDistancesToRestaurants().at(i).GetNextID()))
            {
                if(DB->AddDistance(list->at(1).GetDistancesToRestaurants().at(i).GetNextID(),
                                list->at(1).GetDistancesToRestaurants().at(i).GetCurrentRestaurantID(),
                                list->at(1).GetDistancesToRestaurants().at(i).GetMiles()))
                {
                    qDebug() << list->at(1).GetDistancesToRestaurants().at(i).GetCurrentRestaurantID();
                    qDebug() <<list->at(1).GetDistancesToRestaurants().at(i).GetNextID();
                    qDebug() <<list->at(1).GetDistancesToRestaurants().at(i).GetMiles();
                    qDebug() << "Add distance Successful 2";
                }
                else
                {
                    qDebug() << "FUCKKKKK IT FAILED";
                }
            }
        }

        DB->ClearRestaurantList();
        DB->DatabaseToRestaurants();
        DB->testDatabase();
    }    
    else
    {
        qDebug() << "FUCKKKKK you didn't change anything";
    }


}
