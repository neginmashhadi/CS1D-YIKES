#ifndef ADDRESTAURANT_H
#define ADDRESTAURANT_H

#include <QDialog>

namespace Ui {
class addRestaurant;
}

class addRestaurant : public QDialog
{
    Q_OBJECT

public:
    explicit addRestaurant(QWidget *parent = nullptr);
    bool returnClicked();
    ~addRestaurant();

private slots:
    void on_pushButton_clicked();

private:
    Ui::addRestaurant *ui;
    bool clicked;
};

#endif // ADDRESTAURANT_H
