#include "mainwindow.h"
#include "Database.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    w.createTable();

    return a.exec();
}
