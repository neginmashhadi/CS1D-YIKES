#ifndef FOODIE_H
#define FOODIE_H

#include <vector>
#include <iostream>
using namespace std;


class Foodie
{
public:
    Foodie();
private:
    vector<string> places;
    double totalDistance;

};

#endif // FOODIE_H
