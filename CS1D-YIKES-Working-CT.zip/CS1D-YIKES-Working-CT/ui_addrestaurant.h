/********************************************************************************
** Form generated from reading UI file 'addrestaurant.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDRESTAURANT_H
#define UI_ADDRESTAURANT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addRestaurant
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;

    void setupUi(QDialog *addRestaurant)
    {
        if (addRestaurant->objectName().isEmpty())
            addRestaurant->setObjectName(QStringLiteral("addRestaurant"));
        addRestaurant->resize(400, 300);
        buttonBox = new QDialogButtonBox(addRestaurant);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(290, 230, 81, 51));
        buttonBox->setOrientation(Qt::Vertical);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Close);
        horizontalLayoutWidget = new QWidget(addRestaurant);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(100, 100, 207, 91));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(horizontalLayoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);


        retranslateUi(addRestaurant);
        QObject::connect(buttonBox, SIGNAL(accepted()), addRestaurant, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), addRestaurant, SLOT(reject()));

        QMetaObject::connectSlotsByName(addRestaurant);
    } // setupUi

    void retranslateUi(QDialog *addRestaurant)
    {
        addRestaurant->setWindowTitle(QApplication::translate("addRestaurant", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("addRestaurant", "Add 2 New Restaurants from NewFile.txt", nullptr));
    } // retranslateUi

};

namespace Ui {
    class addRestaurant: public Ui_addRestaurant {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDRESTAURANT_H
